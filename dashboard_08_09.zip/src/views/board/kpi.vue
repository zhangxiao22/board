<template>
  <div class="event-list-container">
    <KpiList></KpiList>
  </div>
</template>
<script>
  import KpiList from '../../components/componentKpiGauge'

  export default {
    components: {
      KpiList,
    },
    data() {
      return {}
    },
  }
</script>
<style scoped lang="less">
  .event-list-container {
    width: 100%;
    height: 100%;
    position: relative;
  }

</style>
<style>
  /* .main-header {
    display: none;
  } */
</style>

